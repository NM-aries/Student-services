
<script src="{{ asset('js/jquery.min.js') }}" ></script>
<script src="{{ asset('js/popper.min.js') }}" ></script>
<script src="{{ asset('js/bootstrap.min.js') }}" ></script>
<script src="{{ asset('js/main.js') }}" ></script>
<script src="{{ asset('js/simplebar.min.js') }}"></script>

<script src="{{ asset('js/custom.js') }}"></script>   
@yield('scripts')
