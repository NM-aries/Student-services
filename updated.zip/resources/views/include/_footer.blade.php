<div class="container">
    <footer class="d-flex flex-wrap justify-content-between align-items-center py-4 ">
      <div class="d-flex align-items-center">
        <span class="">© 2022 - All rights reserved.</span>
      </div>

      <div class="d-flex align-items-center">
        <span class="">Developed by EVSU - Student Services Department</span>
      </div>
    </footer>
  </div>