
<style>
    p{
        font-family: sans-serif;
    }
</style>

<p>
    Hi, <br>
    There is a new update on website check it out!
    <br>
    <br>

<strong>Title</strong> {{ $data['title'] }} <br>
<strong>Description: </strong> {!! $data['description'] !!}

</p>