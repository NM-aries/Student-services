

<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid bg-light-green shadow" id="title_container">
    <div class="container">
        <div class="header pb-2 pt-3">
            <h2 class="text-white">Services</h2>
        </div>
   </div>
</div>

<div class="container mb-5 mt-4" >
    <div class="row new_content ">
        <div class="col-lg-12 col-md-12 col-12 order-1 ">
            <div class="accordion rounded-0 " id="accordionPricing">
            <?php if($allServices->count()): ?>
                <?php $__currentLoopData = $allServices->where('status', 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listServices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion-item rounded-0">
                        <h2 class="accordion-header " id="headingOne">
                            <button class="accordion-button collapsed bg-light-green text-white rounded-0
                                <?php if(!$loop->first): ?> collapsed <?php endif; ?>" 
                                type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne-<?php echo e($listServices->id); ?>" aria-expanded="true" aria-controls="collapseOne">
                                <?php echo e($listServices->title); ?>

                            </button>
                        </h2>
                        <div id="collapseOne-<?php echo e($listServices->id); ?>" class="accordion-collapse show collapse collapsed  " aria-labelledby="headingOne" data-bs-parent="#accordionPricing">
                            <div class="accordion-body bg-white">
                                <?php echo $listServices->description; ?>  

                                <?php if($listServices->file): ?>
                                    <div class="my-2">
                                         </a>
                                    </div> 
                                    <div class="d-flex justify-content-between align-items-center">
                                        <a id="download_link" href="<?php echo e(asset('upload/services/')); ?>/<?php echo e($listServices->file); ?>" target="_blank" class="btn btn-green"> Dowload Now</a>
                                        <span class="badge bg-green py-3  rounded-0 px-2">
                                            <span class="text-white mx-2"><?php echo e($listServices->download_count); ?></span> 
                                            Downloads
                                        </span>
                                    </div>

                                <?php endif; ?>

                            </div>
                        </div>
                    </div>

                    
                    <form class="hidden" action="<?php echo e(url('servicesDownload/'.$listServices->id)); ?>" method="POST" id="form" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?> 
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" value="<?php echo e($listServices->download_count); ?>" name="download_count" id="DownloadCount">
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
                
            <?php else: ?>
                <div class="card-body bg-light-green text-white mb-5 rounded-md">
                    <div class="row">
                        <div class="col-2">
                            <img class="w-100" src="https://cdn.shopify.com/s/files/1/1061/1924/products/Sad_Face_Emoji_large.png?v=1571606037" alt="">
                        </div>
                        <div class="col-10">
                            <h4 class="text-white">SORRY !</h4>
                            <p class="lead">
                                NO POST AVAILABLE RIGHT NOW 
                                <br>
                                PLEASE COMEBACK LATER THANK YOU..
                            </p>
                            
                        </div>
                    </div>
                </div>
            <?php endif; ?>
       </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        document.getElementById("download_link").onclick = function() {
            let downloadCount = document.getElementById('DownloadCount').value;
            let downloadCountPlusOne = parseInt(downloadCount) + 1;
            document.getElementById('DownloadCount').value = downloadCountPlusOne;
            
            let $formData = $('#form');
        
            $.ajax({
                url: $formData.attr('action'),
                type: 'PUT',
                data: $formData.serialize(),
            });
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\finalblog\resources\views/services.blade.php ENDPATH**/ ?>