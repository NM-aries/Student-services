
    <div id="carouselExampleIndicators" class="carousel slide mb-3" data-bs-ride="true">
        <div class="carousel-indicators">
            <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indicator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" data-bs-target="#carouselExampleIndicators" aria-current="true" aria-label="Slide 1"
                    data-bs-slide-to="<?php echo e($loop->index); ?>" 
                    <?php if($loop->first): ?> class=" bg-primary active" <?php endif; ?>>
                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="carousel-inner bg-gray">
            <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banners): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div <?php if($loop->first): ?> class="carousel-item active" <?php endif; ?> class="carousel-item" >
                    <a <?php if($banners->link): ?>
                            href="<?php echo e($banners->link); ?>" target="_blank" 
                        <?php else: ?> 
                            href="#" 
                        <?php endif; ?>>
                        <div class="img">
                            <img class="d-block img-fluid" width="100%" src="<?php echo e(asset('upload/banner/'. $banners->image)); ?>" alt="<?php echo e($banners->description); ?>">
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
            <svg xmlns="http://www.w3.org/2000/svg" class="text-primary" width="30" height="30" fill="currentColor" class="bi bi-caret-left-fill" viewBox="0 0 16 16">
                <path d="m3.86 8.753 5.482 4.796c.646.566 1.658.106 1.658-.753V3.204a1 1 0 0 0-1.659-.753l-5.48 4.796a1 1 0 0 0 0 1.506z"/>
            </svg>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
            <svg xmlns="http://www.w3.org/2000/svg" class="text-primary" width="30" height="30" fill="currentColor" class="bi bi-caret-right-fill" viewBox="0 0 16 16">
                <path d="m12.14 8.753-5.482 4.796c-.646.566-1.658.106-1.658-.753V3.204a1 1 0 0 1 1.659-.753l5.48 4.796a1 1 0 0 1 0 1.506z"/>
              </svg>
        </button>
    </div><?php /**PATH F:\finalblog\resources\views/include/_banner.blade.php ENDPATH**/ ?>